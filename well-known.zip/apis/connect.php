<?php

$conn = mysqli_connect("localhost", "logicalh_farwa", "Racespeed@#!@", "logicalh_farwa");

?>
